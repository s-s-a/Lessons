import pyodbc

conn = pyodbc.connect('''Driver={ODBC Driver 17 for SQL Server};Server=DB;
                      Database=master;Trusted_Connection=yes;APP=Pyton App;
                      Workstation=WS32''')
# conn.setdecoding(pyodbc.SQL_CHAR,encoding='utf-8')
cursor = conn.cursor()
cursor.execute('select @@version')
for row in cursor:
    print(row)

conn.close()
