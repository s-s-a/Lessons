#!c:\Users\Sizov\AppData\Local\Programs\Python\Python37\python

import wx

app = wx.App()

frame = wx.Frame(None, -1, 'simple.py')
frame.Show()

app.MainLoop()